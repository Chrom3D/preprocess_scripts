// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen

#ifndef GUARD_CCCStatistics
#define GUARD_CCCStatistics

#include "CCCMatrix.h"
#include "Segment.h"
#include <assert.h>

#include <map>
#include <vector>

#include <algorithm>
#include <numeric> 

#include "../spline/spline.h" // Spline-smoothing
#include "../stocc/stocc.h" // Non-central hypergeometric and Poisson

typedef CCCMatrix<int> ContactMatrix;
typedef CCCMatrix<float> ExpectationMatrix;
typedef CCCMatrix<double> PvalueMatrix;

// Allowing for vector concatenation via addition:

template <typename T>
std::vector<T> operator+(const std::vector<T> &A, const std::vector<T> &B)
{
  std::vector<T> AB;
    AB.reserve( A.size() + B.size() );         
    AB.insert( AB.end(), A.begin(), A.end() ); 
    AB.insert( AB.end(), B.begin(), B.end() ); 
    return AB;
}

template <typename T>
std::vector<T> &operator+=(std::vector<T> &A, const std::vector<T> &B)
{
    A.reserve( A.size() + B.size() );          
    A.insert( A.end(), B.begin(), B.end() );   
    return A;                                  
}



std::map<int, std::vector<int> > getValuesPerDelta(ContactMatrix&, int minDelta=8000, int maxDelta=MAXDELTA, bool masking=false);
std::map<int, std::vector<int> > getValuesPerDelta(ContactMatrix&, std::map<int,int>&, int minDelta=8000, int maxDelta=MAXDELTA, bool masking=false);
std::map<int, std::vector<int> > getValuesPerDelta(std::map<std::string, ContactMatrix>&, std::map<int,int>&, int minDelta=8000, int maxDelta=MAXDELTA, bool masking=false);
std::map<int,int> computeQuantileMapper(std::vector<int>&, unsigned int);
std::map<int, float> getMeanPerDelta(std::map<int, std::vector<int> >&);

template<typename T> std::map<Segment, T> getGlobalMarginalSumMapper(std::map<std::string, CCCMatrix<T> >&, bool onlyIntra=true);
  
ExpectationMatrix createExpectationMatrix(ContactMatrix&, std::map<int, float>&, int minDelta=8000, int maxDelta=MAXDELTA);
ExpectationMatrix createExpectationMatrix(ContactMatrix&, spline&, int minDelta=8000, int maxDelta=MAXDELTA);
template<typename T> std::map<Segment,T> getMarginalSumMapper(CCCMatrix<T>&,  IndexType marginal=INTRAINDEX); 
std::map<Segment, float> estimateMarginalBias(ContactMatrix&, ExpectationMatrix&, int nIter=20);
double getPvalNCHG(int, int, int, int, double, double precision=1E-20, double minOmega=0.1);
int getQuantileNCHG(double, int, int, int, double, double precision=1E-20, bool lower_tail=true);
double getCumulativeNCHG(int, int, int, int, double, double precision=1E-20, bool lower_tail=true);
double getCumulativeNCHG2(int, int, int, int, double, double precision=1E-20, bool lower_tail=true);
 
PvalueMatrix calculatePvalues(ContactMatrix&, ExpectationMatrix&, int minDelta=8000, int maxDelta=MAXDELTA);
ExpectationMatrix getOddsRatios(ContactMatrix&, ExpectationMatrix&, int minDelta=8000, int maxDelta=MAXDELTA);
void printPositives(PvalueMatrix&, ContactMatrix&, ExpectationMatrix&, double, int, bool printNij=false);
void printPositives(PvalueMatrix&, ContactMatrix&, ExpectationMatrix&,  std::map<Segment, int>&, std::map<Segment, float>&, double, int, int minDelta=8000, int maxDelta=MAXDELTA, bool globalN=false);
double getMeanInterchromosomal(std::map<std::string, ContactMatrix>&);
  
// Utils:
template<typename T> std::vector<T> getSequence(T, T, int);
std::pair<double, double> getAlphaRange(std::map<double, double> , double);
void maskByAlpha(PvalueMatrix&, ContactMatrix&, double, int);

std::map<double, double> estimateFDR(std::vector<std::string>, std::map<std::string, ContactMatrix>&, std::map<std::string, ExpectationMatrix>&, std::map<std::string, PvalueMatrix>&, double, double, double, int cutoff=3, int deltaCutoff=8000, int maxDelta=MAXDELTA);

std::pair<spline, std::vector<double> > estimateDeltaSpline(std::vector<std::string>, std::map<std::string, ContactMatrix>&, int minDelta=8000, int maxDelta=MAXDELTA, bool masking=false, int percentiles=1000);

PvalueMatrix calculatePvalues(ContactMatrix&, ExpectationMatrix&, std::map<Segment, int>&, std::map<Segment, float>&, int minDelta=8000, int maxDelta=MAXDELTA, bool globalN=false);


#endif
