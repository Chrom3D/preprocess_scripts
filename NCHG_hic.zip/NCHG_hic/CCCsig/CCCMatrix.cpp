// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen


#include "CCCMatrix.h"
#include <assert.h>
#include <iostream>

using namespace std;



template <class T> CCCMatrix<T>::CCCMatrix() {
  nRow=0;
  nCol=0;
  isIntra=true;
  defaultVal=0;
  N=0;
}

template <class T> CCCMatrix<T>::CCCMatrix(set<Segment> rows, set<Segment> cols, T defaultvalue, bool isintra) {
  nRow = rows.size();
  nCol = cols.size();
  isIntra = isintra;
  defaultVal = defaultvalue;
  
  // Sanity checks:
  assert(nRow>0);
  assert(nCol>0);
  if (isintra) { 
    assert(rows==cols); 
  }
  else {
    // Obs: This could be made more sophisticated. 
    // None of the elements in rows and cols should be allowed to be the same!
    assert(rows!=cols); 
  }
  
  // Create the (empty) matrix:
  vector<vector<T> > mat(nRow, vector<T>(nCol, defaultVal));
  //vector<vector<T> >mat;
  //mat.resize(nRow, vector<T>( nCol , defaultVal ) );
  matrix = mat;

  // Create (empty) masking matrix:
  vector<vector<bool> > maskmat;
  maskmat.resize(nRow, vector<bool>( nCol , false ) );
  mask = maskmat;

  // Create mappers from rows/cols to matrix indices:
  
  map<Segment, pair<MatrixIndex,IndexType> > getrowcol;

  typedef set<Segment>::iterator setiter;
  
  int rowcounter=0;
  int colcounter=0;
  if(isintra) {    
    for (setiter it = rows.begin(); it != rows.end(); ++it) {
      getrowcol[*it] = make_pair(rowcounter, INTRAINDEX);
      rowcounter++;
    }
  }
  else {
    for (setiter it = rows.begin(); it != rows.end(); ++it) {
      getrowcol[*it] = make_pair(rowcounter,ROWINDEX);
      rowcounter++;
    }
    for (setiter it = cols.begin(); it != cols.end(); ++it) {
      getrowcol[*it] = make_pair(colcounter,COLINDEX);
      colcounter++;
    }
  }
  getRowCol = getrowcol;
}

template <class T> void CCCMatrix<T>::printMatrix(bool hideMask /*=false*/) {
  for(MatrixIndex i=0; i<matrix.size(); i++) {
    for(MatrixIndex j=0; j<matrix[0].size(); j++) {
      if(mask[i][j] and hideMask) {
	cout << "NA ";
      }
      else {
	cout << matrix[i][j] << " ";
      }
    }
    cout << endl;
  }
}

template <class T> bool CCCMatrix<T>::isValidColumn(Segment col) {
  if(getRowCol[col].second == 0) {
    return false;
  }
  if(getRowCol[col].second == ROWINDEX) {
    return false;
  }
  return true;
}

template <class T> bool CCCMatrix<T>::isValidRow(Segment row) {
  if(getRowCol[row].second == 0) {
    return false;
  }
  if(getRowCol[row].second == COLINDEX) {
    return false;
  }
  return true;
}


template <class T> T CCCMatrix<T>::getElement(Segment row, Segment col) {
  assert( this->isValidRow(row));
  assert( this->isValidColumn(col));

  int rowIndex = getRowCol[row].first;
  int colIndex = getRowCol[col].first;

  //return matrix.at(rowIndex).at(colIndex); // Does boundary checks
  return matrix[rowIndex][colIndex]; // Does not do boundary checks
}

template <class T> void CCCMatrix<T>::setElement(Segment row, Segment col, T val) {
  assert( this->isValidRow(row));
  assert( this->isValidColumn(col));

  int rowIndex = getRowCol[row].first;
  int colIndex = getRowCol[col].first;

  matrix[rowIndex][colIndex] = val;
  if (isIntra) {
    matrix[colIndex][rowIndex] = val;
  }
}

template <class T> void CCCMatrix<T>::setMask(Segment row, Segment col) {
  assert( this->isValidRow(row));
  assert( this->isValidColumn(col));

  int rowIndex = getRowCol[row].first;
  int colIndex = getRowCol[col].first;

  mask[rowIndex][colIndex] = true;
  if (isIntra) {
    mask[colIndex][rowIndex] = true;
  }
}

template <class T> bool CCCMatrix<T>::isMasked(Segment row, Segment col) {
  assert( this->isValidRow(row));
  assert( this->isValidColumn(col));
  int rowIndex = getRowCol[row].first;
  int colIndex = getRowCol[col].first;
  return mask[rowIndex][colIndex];
}




template <class T> T CCCMatrix<T>::colSum(Segment col) {
  assert(this->isValidColumn(col));
  MatrixIndex j=getRowCol[col].first;
  T colsum = 0;
  for(MatrixIndex i=0; i<this->nRow; i++) {
    colsum += matrix[i][j];
  }
  return colsum;
}

template <class T> T CCCMatrix<T>::rowSum(Segment row) {
  assert(this->isValidRow(row));
  MatrixIndex i=getRowCol[row].first;
  T rowsum = 0;
  for(MatrixIndex j=0; j<this->nCol; j++) {
    rowsum += matrix[i][j];
  }
  return rowsum;
}

template <class T> T CCCMatrix<T>::sum() {
  T sum = 0;
  for(MatrixIndex i=0; i<this->nRow; i++) {
    for(MatrixIndex j=0; j<this->nCol; j++) {
      sum += matrix[i][j];
    }
  }
  return sum;
}


template <class T> int CCCMatrix<T>::nElem() {
  int nElem = 0;
  for(MatrixIndex i=0; i<this->nRow; i++) {
    for(MatrixIndex j=0; j<this->nCol; j++) {
      nElem++;
    }
  }
  return nElem;
}

template <class T> T CCCMatrix<T>::avg() {
  return this->sum()/this->nElem();
}




template <class T> T CCCMatrix<T>::weightedRowSum(Segment row, map<Segment, float> weights) {
  assert(this->isValidRow(row));
  assert(isIntra);
  set<Segment> columns = this->getSegments(INTRAINDEX); // Deltas only make sence for intra-data.
  T rowsum = 0;
  typedef set<Segment>::iterator It;
  for (It colIter = columns.begin(); colIter != columns.end(); ++colIter) {
    rowsum += this->getElement(row, *colIter) * weights[*colIter];
  }
  return rowsum;
}



  //getRowCol
//  std::map<Segment, std::pair<MatrixIndex,IndexType> > getRowCol; 
template <class T> set<Segment> CCCMatrix<T>::getSegments(IndexType idxtype) {
  typedef map<Segment, pair<MatrixIndex,IndexType> >::iterator it_type;
  set<Segment> res;
  for(it_type iterator = getRowCol.begin(); iterator != getRowCol.end(); iterator++) {
    if(iterator->second.second == idxtype) {
      res.insert(iterator->first);
    }
  }
  return res;
}

template <class T> vector<int> CCCMatrix<T>::getDeltas(int minDelta /* = 0 */, int maxDelta /*=MAXDELTA*/, bool masking /* =false */) {
  assert(isIntra);
  set<Segment> segments = this->getSegments(INTRAINDEX); // Deltas only make sence for intra-data.
  typedef set<Segment>::iterator It;
  vector<int> res;
  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      int delta=(*i)-(*j);
      if(delta>=minDelta and delta<=maxDelta) {
	if(not (masking and this->isMasked(*i,*j))) {
	  res.push_back(delta);
	}
      }
    }
  }
  return res;
}

template <class T> T CCCMatrix<T>::getN(int minDelta /* = 0 */, int maxDelta /*=MAXDELTA*/) {
  if(not isIntra) {
    return this->sum();
  }
  set<Segment> segments = this->getSegments(INTRAINDEX); // Deltas only make sence for intra-data.
  typedef set<Segment>::iterator It;
  T res = 0;
  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      int delta=(*i)-(*j);
      if(delta>=minDelta and delta<=maxDelta) {
	res += this->getElement((*i), (*j));
      }
    }
  }
  return res;
}

template <class T> void CCCMatrix<T>::normalize() {
  set<Segment> segments = this->getSegments(INTRAINDEX); // Deltas only make sence for intra-data.
  typedef set<Segment>::iterator It;

  T N = this->getN();
  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      this->setElement(*i, *j, this->getElement(*i, *j) / N);
    }
  }
}

template <class T> void CCCMatrix<T>::scale(float scalar) {
  set<Segment> segments = this->getSegments(INTRAINDEX); // Deltas only make sence for intra-data.
  typedef set<Segment>::iterator It;

  for (It i = segments.begin(); i != segments.end(); ++i) {
    for (It j = i; ++j != segments.end(); /**/) {
      this->setElement(*i, *j, this->getElement(*i, *j) * scalar);
    }
  }
}



// Add the possible template classes explicitly, to allow linker to find them:
template class CCCMatrix<int>;
template class CCCMatrix<bool>;
template class CCCMatrix<float>;
template class CCCMatrix<double>;
