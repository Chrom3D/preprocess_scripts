// Detection of significant interactions in Hi-C data using Non-central hypergeometric distribution (NCHG)
// This file is subject to the terms and conditions defined in file 'LICENSE', which is part of this source code package.
// Copyright (2017) Jonas Paulsen


#include "../CCCsig/CCCMatrix.h"
#include "../CCCsig/Segment.h"
#include "../CCCsig/CCCStatistics.h"
#include "../CCCsig/CCCDataReader.h"

#include <set>
#include <iostream>
#include <fstream>
#include <sstream>
#include <assert.h>

#include <cstdio>
#include <cstdlib>
#include <vector>

#include "../stocc/stocc.h" // Non-central hypergeometric

#include "../tclap-1.2.1/include/tclap/CmdLine.h" // Command-line parsing

using namespace std;


void print_spline(spline s1, vector<double> deltas, bool errstream = true) {
  for(unsigned int i=0; i != deltas.size(); i++) {
    if (errstream) {
      cerr << deltas[i] << " " << s1(deltas[i]) << endl;    
    }
    else {
      cout << deltas[i] << " " << s1(deltas[i]) << endl;    
    }
  } 
}


int main(int argc, char** argv) {
    	try {  
	TCLAP::CmdLine cmd("This script identifies significant Hi-C interactions using the Non-central Hypergeometric (NCHG) distribution. Copyright (2017) Jonas Paulsen" , ' ', "1.0");

	TCLAP::ValueArg<unsigned int> percentilesArg("n","quantiles","Number of quantiles to use for estimating the expected number of interactions given the genomic distance (default is 100)",false,100,"int");
	cmd.add( percentilesArg );
	

	TCLAP::SwitchArg printdeltaSwitch("d","printdelta","Print estimated expectation values to stderr", false);
	cmd.add( printdeltaSwitch );


	TCLAP::SwitchArg printInteractionCountsSwitch("p","printcounts","Print observed and expected number of interactions for each significant interaction, in addition to the Odds-Ratio and the P-value", false);
	cmd.add( printInteractionCountsSwitch );

	
	TCLAP::SwitchArg onlyprintdeltaSwitch("o","onlyprintdelta","Estimate the expectation values then print estimated expectation values to stdout and exit. No P-values are calculated. Suitable for exploring the effect of choosing different number of quantiles (-n).", false);
	cmd.add( onlyprintdeltaSwitch );
       

	TCLAP::ValueArg<int> mindeltaArg("m","mindelta","Minumum genomic distance (in bp) allowed between anchor pairs, below which interactions are excluded. (default is 40000 bp)",false,40000,"int");
	cmd.add( mindeltaArg );


	TCLAP::ValueArg<int> maxdeltaArg("M","maxdelta","Maximum genomic distance (in bp) allowed between anchor pairs, above which interactions are excluded. (Default is no maximum value)",false,MAXDELTA,"int");
	cmd.add( maxdeltaArg );

	TCLAP::ValueArg<string> selectChrArg("u","onlyChr","Use only the specified chromosome for P-value calculations. Default behaviour is to use all chromosomes. Even if a chromosome is specified using this argument, all chromosomes will be used for estimation of expected number of interactions.",false,"","string");
	cmd.add( selectChrArg );

	TCLAP::SwitchArg useInterArg("i","useInter","Use interchromosomal interactions (between chromosomes) that are given in the input file. By default, only intrachromosomal (within chromosomes) are considered. Including interchromosomal data can result in loss of power for intrachromosomal interactions, as many more hypothesis tests have to be performed.",false);
	cmd.add( useInterArg );

	TCLAP::SwitchArg NoCorrectChromArg("z","nochromcorrection","Do NOT correct for chromosomal differences. By default, chromosomal differences are corrected for when intrachromosomal data are used, and NOT corrected for when interchromosomal data are used (i/--useInter). The latter is forced, and cannot be changed", false);
	cmd.add( NoCorrectChromArg );


	
	TCLAP::UnlabeledValueArg<string> nolabel( "filename", "Input file of the format chrA startA endA chrB startB endB I(A,B) where I(A,B) gives the number of interactions between A and B. This corresponds to the BEDPE format described here: http://bedtools.readthedocs.org/en/latest/content/general-usage.html#bedpe-format", true, "/dev/null", "filename"  );
	cmd.add( nolabel );

	cmd.parse( argc, argv );

	unsigned int percentiles = percentilesArg.getValue();
	int minDelta = mindeltaArg.getValue();
	int maxDelta = maxdeltaArg.getValue();
	bool printDelta = printdeltaSwitch.getValue();
	bool onlyprintDelta = onlyprintdeltaSwitch.getValue();
	string fileName = nolabel.getValue();



	bool printNij = printInteractionCountsSwitch.getValue();

	string selectChr = selectChrArg.getValue();

	bool useInterData = useInterArg.getValue();

	int deltaCutoff=minDelta;
	bool noCorrectChrom = NoCorrectChromArg.getValue();
	bool globalN = (useInterData ? true : noCorrectChrom);
	
	assert(minDelta >= 0);	





	// READING THE DATA:
	CCCDataReader dr(fileName);
	vector<string> chromosomes=dr.getChromosomes(true); // intra-chromosomes
	//assert(chromosomes.size() > 0);
	vector<pair<string,string> > interChromosomes;

	if(useInterData) {
	  interChromosomes = dr.getInterChromosomePairs();
	  assert(interChromosomes.size() > 0);
	  dr.buildContactMatrices(false);
	}
	else {
	  dr.buildContactMatrices(true);
	}
	
       
	
	// Get contact-matrices:
	bool chrWasFound = (selectChr == "") ? true : false;
	map<string, ContactMatrix> contactMatrices;

	// Intra:
	int intraChrom = 0;
	int interChrom = 0;
	string chr;
	//cout << "chromosomes.size()" << chromosomes.size() << endl;
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
 	  chr=chromosomes[i];
	  contactMatrices[chr] = dr.getContactMatrix(chr);
	  //cout << "chr read: " << chr << " Num. interactions: " << contactMatrices[chr].getN() << endl;
	  if(selectChr != "" and chr == selectChr) {
	    chrWasFound = true;
	  }
	  intraChrom++;
	}
	assert(chrWasFound);
	// Inter:
	for(unsigned int i=0; i!=interChromosomes.size(); i++) {
	  pair<string, string> chrPair = interChromosomes[i];
	  string dummyPair = chrPair.first + ";" + chrPair.second; // Dummy chromosome name, containing both chromosomes
	  //expectationMatrices[dummyPair] = createExpectationMatrix(interContactMatrices[chrPair], interMap, -1, -1);
	  //pvalMatrices[dummyPair] = calculatePvalues(interContactMatrices[chrPair], expectationMatrices[dummyPair], -1, -1);
	  contactMatrices[dummyPair] = dr.getContactMatrix(chrPair);
	  chromosomes.push_back(dummyPair);
	  interChrom++;
	}


	// Estimate the spline-object, for the first time:
	//cout << "Estimating splines.."  << endl;
	
	pair<spline, vector<double> > splineObj;
	spline s;
	vector<double> deltas;	
	if(intraChrom > 0) {
	  splineObj = estimateDeltaSpline(chromosomes, contactMatrices, deltaCutoff, MAXDELTA, false, percentiles); // Spline is estimated on all delta>minDelta
	  s = splineObj.first;
	  deltas = splineObj.second;
	}

	//cout << "Splines estimated" << endl;
	
	if(onlyprintDelta) {
	  int dmax = (maxDelta == MAXDELTA) ? deltas.back() / 100 : maxDelta;
	  vector<double> d = getSequence((double)deltaCutoff, (double)dmax, 2000);
	  print_spline(s, d, false);
	  return 0;
	}
  
	map<string, ExpectationMatrix> expectationMatrices;
	map<string, PvalueMatrix> pvalMatrices;


	

	map<int, float> interMap;
	float avgInterChrom = getMeanInterchromosomal(contactMatrices);
	interMap[-1] = avgInterChrom; // -1 is the "delta" value for interchromosomal data.

	// Make expectation-matrices:
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
	  chr=chromosomes[i];
	  if(contactMatrices[chr].isIntra) {
	    expectationMatrices[chr] = createExpectationMatrix(contactMatrices[chr], s, minDelta, MAXDELTA); // Expectations are calculated for all deltas>minDelta
	  }
	  else {
	    expectationMatrices[chr] = createExpectationMatrix(contactMatrices[chr], interMap, -1, -1);
	  }
	}

	// Calculate marginals:
	map<Segment, int> marginalCounts = getGlobalMarginalSumMapper(contactMatrices, false);
	map<Segment, float> marginalExpectations = getGlobalMarginalSumMapper(expectationMatrices, true);

	// Calculating P-values (first time):
	for(unsigned int i=0; i!=chromosomes.size(); i++) {
	  chr=chromosomes[i];
	  if(contactMatrices[chr].isIntra) {
	    pvalMatrices[chr] = calculatePvalues(contactMatrices[chr], expectationMatrices[chr], marginalCounts, marginalExpectations, deltaCutoff, MAXDELTA, false);
	  }
	  else {
	    pvalMatrices[chr] = calculatePvalues(contactMatrices[chr], expectationMatrices[chr], marginalCounts, marginalExpectations, -1, -1, globalN);
	  }
	}

	//cout << "Expectation and P-values calculated" << endl;
	


	// ----
	
	if (selectChr != "") {
	  vector<string> selChr;
	  selChr.push_back(selectChr);
	  chromosomes = selChr;
	}
	
	  for(unsigned int i=0; i!=chromosomes.size(); i++) {
	    chr=chromosomes[i];
	    if(printNij) {
	      printPositives(pvalMatrices[chr], contactMatrices[chr], expectationMatrices[chr], marginalCounts, marginalExpectations, 1.0, 0, minDelta, maxDelta, globalN);
	    }
	    else {
	      printPositives(pvalMatrices[chr], contactMatrices[chr], expectationMatrices[chr], 1.0, 0, false); // Everything is printed. Including 0s.
	    }
	  }	  


	// Print the estimated expectation values:
	if(printDelta) {
	  print_spline(s, deltas);
        }


        }
	 catch (TCLAP::ArgException &e)  // catch any exceptions
	{ 
	  std::cerr << "error: " << e.error() << " for arg " << e.argId() << std::endl; 
	}


  return 0;
}
	
	




